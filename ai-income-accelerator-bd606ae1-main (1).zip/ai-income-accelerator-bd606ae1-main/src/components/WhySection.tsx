import { CheckCircle2, Target, Heart, Lightbulb, Users, RefreshCcw } from "lucide-react";
import whyMeBg from "@/assets/why-me-bg.png";

const reasons = [
  {
    icon: CheckCircle2,
    title: "Practical, Real-World AI Use",
    description: "Not theory — you learn to actually use AI in your work and business."
  },
  {
    icon: Heart,
    title: "Beginner-Friendly Teaching",
    description: "Complex AI concepts explained in simple, actionable steps."
  },
  {
    icon: Target,
    title: "Business & Income Focused",
    description: "Every lesson is designed to help you earn or grow."
  },
  {
    icon: RefreshCcw,
    title: "Latest AI Research",
    description: "Continuous updates on new tools and strategies."
  },
  {
    icon: Users,
    title: "Community Support",
    description: "Join a network of learners and get mentorship."
  },
  {
    icon: Lightbulb,
    title: "Proven Systems",
    description: "Frameworks that have helped hundreds succeed."
  }
];

const WhySection = () => {
  return (
    <section id="why" className="section-padding relative overflow-hidden">
      {/* Background Image with 5% opacity */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-5"
        style={{ backgroundImage: `url(${whyMeBg})` }}
      />
      <div className="container-custom relative z-10 px-4">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-20 items-center">
          {/* Content */}
          <div>
            <span className="text-primary font-semibold text-sm uppercase tracking-wider">Why CoachRony?</span>
            <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mt-3 sm:mt-4 mb-4 sm:mb-6">
              Learn AI From Someone Who <span className="text-gradient">Actually Uses It</span>
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg mb-6 sm:mb-8">
              I don't just teach AI — I use it daily to run my business, create content, and help others grow. My approach is hands-on, practical, and focused on real results.
            </p>
            
            {/* Vision */}
            <div className="p-4 sm:p-6 rounded-xl glass-effect border border-primary/20">
              <h3 className="font-heading text-lg sm:text-xl font-bold text-foreground mb-2 sm:mb-3">🎯 My Vision</h3>
              <p className="text-sm sm:text-base text-muted-foreground">
                To build one of the most <strong className="text-foreground">trusted AI education brands</strong> in Bangladesh and beyond — helping people turn AI into skills, confidence, and income.
              </p>
            </div>
          </div>
          
          {/* Reasons Grid */}
          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            {reasons.map((reason, index) => (
              <div 
                key={index}
                className="p-3 sm:p-5 rounded-xl bg-gradient-card border border-border/50 hover:border-primary/30 transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <reason.icon className="w-6 sm:w-8 h-6 sm:h-8 text-primary mb-2 sm:mb-3" />
                <h4 className="font-heading text-sm sm:text-base font-bold text-foreground mb-1 sm:mb-2">{reason.title}</h4>
                <p className="text-xs sm:text-sm text-muted-foreground">{reason.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhySection;
