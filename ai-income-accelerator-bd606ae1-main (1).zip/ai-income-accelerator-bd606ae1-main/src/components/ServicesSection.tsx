import { Sparkles, Package, Zap, Users } from "lucide-react";

const services = [
  {
    icon: Sparkles,
    title: "AI Content Creation",
    description: "Create reels, posts, scripts, videos, and AI-avatar content using modern AI tools."
  },
  {
    icon: Package,
    title: "Digital Product & Income Systems",
    description: "Turn your knowledge into courses, eBooks, programs, and automated funnels."
  },
  {
    icon: Zap,
    title: "AI Marketing & Automation",
    description: "Sales pages, landing pages, WhatsApp automation, email flows, and lead generation systems."
  },
  {
    icon: Users,
    title: "Coaching & Mentorship",
    description: "Step-by-step guidance, live programs, and community-based learning."
  }
];

const ServicesSection = () => {
  return (
    <section id="services" className="section-padding">
      <div className="container-custom px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-16">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">What I Help You With</span>
          <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mt-3 sm:mt-4 mb-4 sm:mb-6">
            Transform Your Skills with <span className="text-gradient">AI Power</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg px-2">
            From content creation to building complete income systems, I help you leverage AI for real results.
          </p>
        </div>
        
        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="group p-5 sm:p-8 rounded-2xl bg-gradient-card border border-border/50 hover:border-primary/50 transition-all duration-300 hover:glow-primary card-shadow animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-12 sm:w-14 h-12 sm:h-14 rounded-xl bg-gradient-primary flex items-center justify-center mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                <service.icon className="w-6 sm:w-7 h-6 sm:h-7 text-primary-foreground" />
              </div>
              <h3 className="font-heading text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-foreground">{service.title}</h3>
              <p className="text-sm sm:text-base text-muted-foreground">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
