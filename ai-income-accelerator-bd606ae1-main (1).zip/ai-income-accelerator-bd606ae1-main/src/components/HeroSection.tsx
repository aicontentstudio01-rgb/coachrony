import { Button } from "@/components/ui/button";
import { Calendar, ArrowRight } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        backgroundImage: `url(${heroBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-background/70" />
      
      {/* Glow effects */}
      <div className="absolute top-1/4 left-1/4 w-48 sm:w-96 h-48 sm:h-96 bg-primary/20 rounded-full blur-3xl animate-pulse-glow" />
      <div className="absolute bottom-1/4 right-1/4 w-48 sm:w-96 h-48 sm:h-96 bg-secondary/20 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1s' }} />
      
      <div className="container-custom section-padding relative z-10 px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 rounded-full glass-effect mb-6 sm:mb-8 animate-fade-in">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse flex-shrink-0" />
            <span className="text-xs sm:text-sm text-muted-foreground">AI Coach | Digital Educator | Business Consultant</span>
          </div>
          
          {/* Headline */}
          <h1 className="font-heading text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold mb-4 sm:mb-6 animate-fade-in leading-tight" style={{ animationDelay: '0.1s' }}>
            Build Income, Content & Smart Systems with{" "}
            <span className="text-gradient">AI</span>
          </h1>
          
          {/* Sub-headline */}
          <p className="text-base sm:text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 sm:mb-10 animate-fade-in px-2" style={{ animationDelay: '0.2s' }}>
            Learn practical AI skills to create content, launch digital products, automate marketing, and grow online income — guided by an experienced AI Coach & Mentor.
          </p>
          
          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center animate-fade-in px-2" style={{ animationDelay: '0.3s' }}>
            <a href="https://wa.me/8801911430005" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
              <Button variant="hero" size="xl" className="group w-full sm:w-auto text-sm sm:text-base">
                <Calendar className="w-4 h-4 sm:w-5 sm:h-5" />
                Book a Free AI Strategy Call
                <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </a>
            <a href="#programs" className="w-full sm:w-auto">
              <Button variant="heroOutline" size="xl" className="w-full sm:w-auto text-sm sm:text-base">
                Explore AI Programs
              </Button>
            </a>
          </div>
          
          {/* Trust indicators */}
          <div className="mt-10 sm:mt-16 flex flex-wrap justify-center gap-6 sm:gap-8 text-muted-foreground animate-fade-in" style={{ animationDelay: '0.4s' }}>
            <div className="text-center min-w-[80px]">
              <div className="text-xl sm:text-2xl font-bold text-foreground">1k+</div>
              <div className="text-xs sm:text-sm">Students Trained</div>
            </div>
            <div className="text-center min-w-[80px]">
              <div className="text-xl sm:text-2xl font-bold text-foreground">6+</div>
              <div className="text-xs sm:text-sm">Years Experience</div>
            </div>
            <div className="text-center min-w-[80px]">
              <div className="text-xl sm:text-2xl font-bold text-foreground">50+</div>
              <div className="text-xs sm:text-sm">AI Tools Mastered</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-float">
        <div className="w-6 h-10 border-2 border-muted-foreground/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-2 bg-primary rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
