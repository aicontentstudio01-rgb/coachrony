import coachPortrait from "@/assets/coach-rony-portrait.jpg";

const AboutSection = () => {
  return (
    <section id="about" className="section-padding bg-gradient-hero">
      <div className="container-custom px-4">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Image */}
          <div className="relative animate-fade-in-left order-2 lg:order-1">
            <div className="relative z-10">
              <img 
                src={coachPortrait} 
                alt="CoachRony - AI Coach and Digital Educator"
                className="w-full max-w-xs sm:max-w-md mx-auto rounded-2xl card-shadow"
              />
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-2 sm:-top-4 -left-2 sm:-left-4 w-full h-full border-2 border-primary/30 rounded-2xl" />
            <div className="absolute -bottom-2 sm:-bottom-4 -right-2 sm:-right-4 w-24 sm:w-32 h-24 sm:h-32 bg-gradient-primary opacity-20 rounded-2xl blur-xl" />
          </div>
          
          {/* Content */}
          <div className="animate-fade-in-right order-1 lg:order-2">
            <span className="text-primary font-semibold text-sm uppercase tracking-wider">About Me</span>
            <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mt-3 sm:mt-4 mb-4 sm:mb-6">
              Hi, I'm <span className="text-gradient">Rony</span> — widely known as <span className="text-gradient">CoachRony</span>
            </h2>
            <p className="text-muted-foreground text-base sm:text-lg mb-4 sm:mb-6">
              I'm an <strong className="text-foreground">AI Coach, Digital Educator, and Consultant</strong> helping students, creators, and entrepreneurs use AI in a <strong className="text-foreground">practical, income-focused way</strong>.
            </p>
            <p className="text-muted-foreground text-base sm:text-lg mb-6 sm:mb-8">
              I believe AI is not just a tool — it's a <strong className="text-foreground">career accelerator</strong> and a <strong className="text-foreground">business growth engine</strong>. My mission is to simplify AI so anyone can use it to:
            </p>
            
            {/* Benefits list */}
            <ul className="space-y-4">
              {[
                "Create content faster",
                "Launch digital products",
                "Build automated systems",
                "Generate sustainable online income"
              ].map((benefit, index) => (
                <li key={index} className="flex items-center gap-3 text-foreground">
                  <span className="w-6 h-6 rounded-full bg-gradient-primary flex items-center justify-center text-primary-foreground text-sm">✓</span>
                  {benefit}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
