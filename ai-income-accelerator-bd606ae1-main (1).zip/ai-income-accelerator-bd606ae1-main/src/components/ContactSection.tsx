import { Button } from "@/components/ui/button";
import { Calendar, ArrowRight, Mail, Phone, Globe, MessageCircle } from "lucide-react";

const ContactSection = () => {
  return (
    <section id="contact" className="section-padding bg-gradient-hero relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-4xl">
        <div className="absolute inset-0 bg-primary/10 blur-3xl rounded-full" />
      </div>
      
      <div className="container-custom relative z-10 px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Header */}
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Ready to Start?</span>
          <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mt-3 sm:mt-4 mb-4 sm:mb-6">
            Begin Your <span className="text-gradient">AI Journey</span> Today
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg mb-8 sm:mb-10 max-w-2xl mx-auto px-2">
            Let AI work for you — not confuse you. Book a free strategy call and discover how AI can transform your content, business, and income.
          </p>
          
          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mb-10 sm:mb-16 px-2">
            <a href="https://wa.me/8801911430005" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
              <Button variant="hero" size="xl" className="group w-full sm:w-auto text-sm sm:text-base">
                <Calendar className="w-4 h-4 sm:w-5 sm:h-5" />
                Book a Free Strategy Call
                <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </a>
            <a href="#programs" className="w-full sm:w-auto">
              <Button variant="heroOutline" size="xl" className="w-full sm:w-auto text-sm sm:text-base">
                Join an AI Program Today
              </Button>
            </a>
          </div>
          
          {/* Contact Info */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
            {[
              { icon: Globe, label: "Website", value: "coachrony.com", href: "https://coachrony.com" },
              { icon: Mail, label: "Email", value: "coachronyacademy@gmail.com", href: "mailto:coachronyacademy@gmail.com" },
              { icon: Phone, label: "Phone", value: "01911430005", href: "tel:01911430005" },
              { icon: MessageCircle, label: "WhatsApp", value: "Message Us", href: "https://wa.me/8801911430005" }
            ].map((contact, index) => (
              <a 
                key={index}
                href={contact.href}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 sm:p-5 rounded-xl glass-effect border border-border/50 hover:border-primary/50 transition-all duration-300 group"
              >
                <contact.icon className="w-5 sm:w-6 h-5 sm:h-6 text-primary mx-auto mb-2 sm:mb-3 group-hover:scale-110 transition-transform" />
                <div className="text-xs sm:text-sm text-muted-foreground">{contact.label}</div>
                <div className="text-foreground font-medium text-xs sm:text-sm mt-1 truncate">{contact.value}</div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
