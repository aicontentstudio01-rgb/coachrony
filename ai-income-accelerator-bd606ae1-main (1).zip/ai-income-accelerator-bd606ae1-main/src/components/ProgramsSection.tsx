import { Button } from "@/components/ui/button";
import { Flame, Rocket, BookOpen, ArrowRight } from "lucide-react";

const programs = [
  {
    icon: Flame,
    badge: "4-Day Intensive",
    title: "AI CASH MACHINE",
    description: "A 4-day intensive AI program designed to help you understand AI fundamentals, tools, and income models.",
    audience: "Perfect for: Beginners, freelancers, and business owners.",
    featured: true,
    link: "https://learn.coachrony.com/"
  },
  {
    icon: Rocket,
    badge: "7-Day Program",
    title: "AI Content Creation Program",
    description: "A beginner-friendly roadmap for people aged 20–35 to master AI-powered content creation.",
    features: ["AI content workflows", "Prompt basics", "Platform-specific strategies", "Consistency systems"],
    featured: false,
    link: "#"
  },
  {
    icon: BookOpen,
    badge: "eBook",
    title: "AI-Powered Digital Product Blueprint",
    description: "A complete guide to building, launching, and scaling digital products using AI.",
    featured: false,
    link: "#"
  }
];

const ProgramsSection = () => {
  return (
    <section id="programs" className="section-padding bg-gradient-hero">
      <div className="container-custom px-4">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-16">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Programs & Offers</span>
          <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mt-3 sm:mt-4 mb-4 sm:mb-6">
            Learn AI the <span className="text-gradient">Practical Way</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg px-2">
            Join our structured programs designed to take you from AI beginner to confident creator.
          </p>
        </div>
        
        {/* Programs Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {programs.map((program, index) => (
            <div 
              key={index}
              className={`relative p-5 sm:p-8 rounded-2xl border transition-all duration-300 animate-fade-in ${
                program.featured 
                  ? 'bg-gradient-card border-primary glow-primary' 
                  : 'bg-gradient-card border-border/50 hover:border-primary/50'
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {program.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-3 sm:px-4 py-1 bg-gradient-primary text-primary-foreground text-xs sm:text-sm font-semibold rounded-full whitespace-nowrap">
                    🔥 Most Popular
                  </span>
                </div>
              )}
              
              <div className="flex items-center gap-3 mb-4 sm:mb-6 mt-2 sm:mt-0">
                <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-xl bg-muted flex items-center justify-center flex-shrink-0">
                  <program.icon className="w-5 sm:w-6 h-5 sm:h-6 text-primary" />
                </div>
                <span className="text-xs sm:text-sm text-muted-foreground font-medium">{program.badge}</span>
              </div>
              
              <h3 className="font-heading text-xl sm:text-2xl font-bold mb-3 sm:mb-4 text-foreground">{program.title}</h3>
              <p className="text-sm sm:text-base text-muted-foreground mb-4 sm:mb-6">{program.description}</p>
              
              {program.audience && (
                <p className="text-xs sm:text-sm text-primary font-medium mb-4 sm:mb-6">{program.audience}</p>
              )}
              
              {program.features && (
                <ul className="space-y-2 mb-4 sm:mb-6">
                  {program.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                      <span className="w-1.5 h-1.5 bg-primary rounded-full flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              )}
              
              <a href={program.link} target={program.link !== "#" ? "_blank" : undefined} rel={program.link !== "#" ? "noopener noreferrer" : undefined}>
                <Button variant={program.featured ? "hero" : "outline"} className="w-full group">
                  Learn More
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProgramsSection;
